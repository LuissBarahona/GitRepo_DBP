//OK
package com.proyecto_dbp.auth.dto;

import lombok.Data;

@Data
public class JwtAuthResponse {
    private String token;

}
