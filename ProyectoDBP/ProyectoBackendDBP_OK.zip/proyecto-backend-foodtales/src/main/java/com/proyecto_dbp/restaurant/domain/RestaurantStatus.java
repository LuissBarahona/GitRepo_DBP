package com.proyecto_dbp.restaurant.domain;

public enum RestaurantStatus {
    OPEN,
    CLOSED
}
