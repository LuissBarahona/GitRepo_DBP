package com.proyecto_dbp.post.domain;

public enum PostStatus {
    ACTIVE,
    DELETED
}
