package com.proyecto_dbp.user.domain;

public enum Role {
    USER
}
