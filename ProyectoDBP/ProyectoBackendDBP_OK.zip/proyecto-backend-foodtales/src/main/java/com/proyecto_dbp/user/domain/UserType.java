package com.proyecto_dbp.user.domain;

public enum UserType {
    CONSUMER,  // Consumidor
    USER, INFLUENCER // Influencer
}
