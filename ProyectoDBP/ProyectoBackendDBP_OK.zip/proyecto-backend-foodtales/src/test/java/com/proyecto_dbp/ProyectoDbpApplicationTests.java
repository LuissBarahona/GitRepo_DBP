package com.proyecto_dbp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoDbpApplicationTests {

	/*
	@Test
	void contextLoads() {
	}
	*/
}
